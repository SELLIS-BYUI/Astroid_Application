#ifndef largeAsteriods_h
#define largeAsteroids_h
#include "rocks.h"

class largeAsteroids : public rocks
{


};
#endif