#ifndef smallAsteroids_h
#define smallAsteroids_h
#include "rocks.h"

class smallAsteroids : public rocks
{


};
#endif