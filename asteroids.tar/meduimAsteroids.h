#ifndef meduimAsteriods_h
#define meduimAsteroids_h
#include "rocks.h"

class meduimAsteroids : public rocks
{


};
#endif