#ifndef flyingObject_h
#define flyingObject_h
#include "point.h"
#include "velocity.h"
#include "uiDraw.h"
#include "flyingObject.h"

class flyingObject
{
protected:
	Point point;
	Velocity velocity;
	bool alive;

public:

	Point getPoint()
	{
		return point;
	}

	Velocity getVelocity()
	{
		return velocity;
	}

	bool isAlive()
	{
		return alive;
	}

	void setVelocity(Velocity velocity)
	{
		this->velocity = velocity;
	}

	void setPoint(Point point)
	{
		this->point = point;
	}

	void kill();
	void advance();
	virtual void draw() = 0;

};
#endif
