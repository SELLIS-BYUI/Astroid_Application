#ifndef otherGameRules_h
#define otherGameRules_h

class otherGameRules
{


};
#endif